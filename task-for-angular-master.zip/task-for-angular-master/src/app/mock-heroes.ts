import { Hero } from './hero';

export const HEROES: Hero[] = [
    { id: 1, name: 'Dr Nice' },
    { id: 1, name: 'Narco' },
    { id: 1, name: 'Bombasto' },
    { id: 1, name: 'Celeritas' },
    { id: 1, name: 'Magneta' },
];